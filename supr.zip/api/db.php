<?php
$host = "localhost";
$dbname = 'u103260206_supreme';
$user = 'u103260206_attend';
$password = 'RIshi@@1496';
$pdo = new PDO(
        'mysql:host=' . $host . ';dbname=' . $dbname, $user, $password
);