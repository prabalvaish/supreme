<?php
$conn=mysqli_connect("localhost","u103260206_attend","RIshi@@1496","u103260206_supreme") or die("Connection Failed");
?>





