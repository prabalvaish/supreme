<?php
defined('BASEPATH') OR exit('Kein direkter Skriptzugriff erlaubt');

/* End of file upload_lang.php */
/* Location: ./system/language/english/pagination_lang.php */