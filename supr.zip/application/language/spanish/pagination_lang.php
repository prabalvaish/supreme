<?php
defined('BASEPATH') OR exit('Kein direkter Skriptzugriff erlaubt');

/* Location: ./system/language/spanish/pagination_lang.php */