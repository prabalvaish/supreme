<?php
defined('BASEPATH') OR exit('Kein direkter Skriptzugriff erlaubt');

/* Location: ./system/language/english/pagination_lang.php */